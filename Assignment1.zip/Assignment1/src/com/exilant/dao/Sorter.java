package com.exilant.dao;

import java.util.Comparator;
import com.exilant.bean.Person;

public class Sorter {
	
		public class SortOnName implements Comparator<Person>{
           @Override
			public int compare(Person o1, Person o2) {
				return o1.getName().compareTo(o2.getName());
			}
		}
		
		public class SortOnId implements Comparator<Person>{
	           @Override
				public int compare(Person o1, Person o2) {
					return o1.getId() - o2.getId();
				}
			}
		
	
}
