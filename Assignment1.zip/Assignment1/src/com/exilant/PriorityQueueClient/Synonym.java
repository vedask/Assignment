package com.exilant.PriorityQueueClient;

import java.util.HashMap;
import java.util.Scanner;

public class Synonym {
	public static void main(String[] args) {
		HashMap<String, String[]> dictionary = new HashMap<>();
		dictionary.put("Happy",new String[]{"joy","delight"});
		dictionary.put("Sad",new String[]{"unhappy","distressed"});
		dictionary.put("angry",new String[]{"furious","mad"});
		for(String key : dictionary.keySet()){
			System.out.println(key);
		}
		System.out.println("Enter the above words to find  synonyms");
		Scanner scanner = new Scanner(System.in);
		String word = scanner.next();
		scanner.close();
		for(String key : dictionary.keySet()){
			if(key.equalsIgnoreCase(word)){
				for(String synonym : dictionary.get(key))
				System.out.print(synonym + " ");
			}
		}
	}
}
