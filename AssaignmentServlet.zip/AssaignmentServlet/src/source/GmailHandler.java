package source;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GmailHandler
 */
@WebServlet("/GmailHandler")
public class GmailHandler extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GmailHandler() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("username");
		String password = request.getParameter("password");
		if(userName.equals("veda")&&password.equals("veda")){
			request.getRequestDispatcher("/views/Home.html").forward(request, response);
		}else{
			 response.setContentType("text/html");
			 PrintWriter out = response.getWriter();
			 request.getRequestDispatcher("/views/Login.html").include(request, response);
			 out.print("<html><body><h5 style='color:red'>Sorry Invalid Credentials</h5></body></html>");
		}
		
		
	}

}
