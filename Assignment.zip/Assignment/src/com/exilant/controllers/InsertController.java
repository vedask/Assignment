package com.exilant.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.exilant.beans.Address;
import com.exilant.beans.Customer;
import com.exilant.beans.Name;
import com.exilant.connection.GetConnection;
import com.exilant.dao.CustomerDAO;

@WebServlet("/InsertController")
public class InsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//		try{
//		out.println("<html>"+Integer.parseInt(request.getParameter("custId")) +"</html>");
//		}catch(NumberFormatException nfe){
//			
//		}
//		out.close();
		CustomerDAO customerDAO = new CustomerDAO();
		if(request.getParameter("insert/update")=="Insert"){
		
		Customer customer = new Customer();
		customer.setCustId(Integer.parseInt(request.getParameter("custId")));
		customer.setName(new Name(request.getParameter("firstName"), request.getParameter("lastName")));
		customer.setIncome(Double.parseDouble(request.getParameter("income")));
		customer.setAddr(new Address(Integer.parseInt(request.getParameter("hNo")), request.getParameter("street"),
				request.getParameter("city"), Integer.parseInt(request.getParameter("pin"))));
		customer.setEmail(request.getParameter("email"));
		
		customerDAO.insertCustomer(customer);
		}
		else if(request.getParameter("insert/update")=="Update"){
			PrintWriter out = response.getWriter();
			try{
			out.println("<html>"+Integer.parseInt(request.getParameter("custId")) +"</html>");
			}catch(NumberFormatException nfe){
				
			}
			out.close();
			//request.getRequestDispatcher("../views/InsertAndUpdate.jsp").forward(request, response);
		}else if(request.getParameter("crud").equals("k")){
			customerDAO.selectCustomers();
			PrintWriter out = response.getWriter();
			try{
			out.println("<html>"+Integer.parseInt(request.getParameter("custId")) +"</html>");
			}catch(NumberFormatException nfe){
				
			}
			out.close();
		}
	}

}
