package com.exilant.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.exilant.beans.Address;
import com.exilant.beans.Customer;
import com.exilant.beans.Name;
import com.exilant.connection.GetConnection;

public class CustomerDAO {
	public boolean insertCustomer(Customer cust) {
		String sql = "insert into Customer2 values(?,?,?,?,?)";
		GetConnection getConnection = new GetConnection();
		 try {
			 getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
			 getConnection.preparedStatement.setInt(1, cust.getCustId());
			 getConnection.preparedStatement.setString(2, cust.getName().getFirstName() +" "+cust.getName().getLastName());
			 getConnection.preparedStatement.setDouble(3, cust.getIncome());
			 getConnection.preparedStatement.setString(4, cust.getAddr().gethNo()+","+cust.getAddr().getStreet()+","+cust.getAddr().getCity()+cust.getAddr().getPin());
			 getConnection.preparedStatement.setString(5, cust.getEmail());
			 return getConnection.preparedStatement.executeUpdate() >0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				getConnection.preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return false;
		
	}
	
	public List<Customer> selectCustomers(){
		String sql = "select * from Customer2";
		List<Customer> list = new ArrayList<>();
		GetConnection getConnection = new GetConnection();
		try {
			getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
			getConnection.rs = getConnection.preparedStatement.executeQuery();
			
			while(getConnection.rs.next()){
				Customer customer = new Customer();
				customer.setCustId(getConnection.rs.getInt(1));
				String[] names = getConnection.rs.getString(2).split(" ");
				Name name = new Name(names[0], names[1]);
				customer.setName(name);
				customer.setIncome(getConnection.rs.getDouble(3));
				String[] addr = getConnection.rs.getString(4).split(",");
				Address address = new Address(Integer.parseInt(addr[0]), addr[1], addr[2], Integer.parseInt(addr[3]));
				customer.setAddr(address);
				customer.setEmail(getConnection.rs.getString(5));
				list.add(customer);
			}
			return list;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				getConnection.preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return list;
	}
	
	public boolean deleteCustomer(int id){
		String sql = "delete from Customer2 where custId=?";
		GetConnection getConnection = new GetConnection();
		 try {
			getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
			 getConnection.preparedStatement.setInt(1, id);
			 return getConnection.preparedStatement.executeUpdate() >0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}


public boolean updateCustomer(Customer cust,int id){
	String sql = "update Customer2 set name = ?,income=?,addr=?,email=?  where custId=?";
	GetConnection getConnection = new GetConnection();
	 try {
		 getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);	
		 getConnection.preparedStatement.setString(1, cust.getName().getFirstName() +" "+cust.getName().getLastName());
		 getConnection.preparedStatement.setDouble(2, cust.getIncome());
		 getConnection.preparedStatement.setString(3, cust.getAddr().gethNo()+","+cust.getAddr().getStreet()+","+cust.getAddr().getCity()+cust.getAddr().getPin());
		 getConnection.preparedStatement.setString(4, cust.getEmail());
		 getConnection.preparedStatement.setInt(5, id);
		 return getConnection.preparedStatement.executeUpdate() >0;
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return false;
}


public List<Customer> selectCustomersOfBanglore(String city){
	String sql = "select * from Customer2 where city=?";
	List<Customer> list = new ArrayList<>();
	GetConnection getConnection = new GetConnection();
	try {
		getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
		getConnection.rs = getConnection.preparedStatement.executeQuery();
		getConnection.preparedStatement.setString(1, city);
		while(getConnection.rs.next()){
			Customer customer = new Customer();
			customer.setCustId(getConnection.rs.getInt(1));
			String[] names = getConnection.rs.getString(2).split(" ");
			Name name = new Name(names[0], names[1]);
			customer.setName(name);
			customer.setIncome(getConnection.rs.getDouble(3));
			String[] addr = getConnection.rs.getString(4).split(",");
			Address address = new Address(Integer.parseInt(addr[0]), addr[1], addr[2], Integer.parseInt(addr[3]));
			customer.setAddr(address);
			customer.setEmail(getConnection.rs.getString(5));
			list.add(customer);
		}
		return list;
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			getConnection.preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return list;
}

public List<Customer> selectCustomersStartWithK(){
	String sql = "select * from Customer2 where city=k";
	List<Customer> list = new ArrayList<>();
	GetConnection getConnection = new GetConnection();
	try {
		getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
		getConnection.rs = getConnection.preparedStatement.executeQuery();
		
		while(getConnection.rs.next()){
			Customer customer = new Customer();
			customer.setCustId(getConnection.rs.getInt(1));
			String[] names = getConnection.rs.getString(2).split(" ");
			Name name = new Name(names[0], names[1]);
			customer.setName(name);
			customer.setIncome(getConnection.rs.getDouble(3));
			String[] addr = getConnection.rs.getString(4).split(",");
			Address address = new Address(Integer.parseInt(addr[0]), addr[1], addr[2], Integer.parseInt(addr[3]));
			customer.setAddr(address);
			customer.setEmail(getConnection.rs.getString(5));
			list.add(customer);
		}
		return list;
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			getConnection.preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return list;
}

public List<Customer> selectCustomersStartWithNoCity(){
	String sql = "select * from Customer2 where city=";
	List<Customer> list = new ArrayList<>();
	GetConnection getConnection = new GetConnection();
	try {
		getConnection.preparedStatement = GetConnection.getOracleConn().prepareStatement(sql);
		getConnection.rs = getConnection.preparedStatement.executeQuery();
		
		while(getConnection.rs.next()){
			Customer customer = new Customer();
			customer.setCustId(getConnection.rs.getInt(1));
			String[] names = getConnection.rs.getString(2).split(" ");
			Name name = new Name(names[0], names[1]);
			customer.setName(name);
			customer.setIncome(getConnection.rs.getDouble(3));
			String[] addr = getConnection.rs.getString(4).split(",");
			Address address = new Address(Integer.parseInt(addr[0]), addr[1], addr[2], Integer.parseInt(addr[3]));
			customer.setAddr(address);
			customer.setEmail(getConnection.rs.getString(5));
			list.add(customer);
		}
		return list;
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		try {
			getConnection.preparedStatement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return list;
}

}